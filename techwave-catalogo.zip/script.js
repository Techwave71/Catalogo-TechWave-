document.querySelectorAll("button").forEach(button => {
    button.addEventListener("click", () => {
        alert("Pronto podrás personalizar tu camiseta con nombre y dorsal.");
    });
});